#!/usr/bin/env python3

from brain_games import logic_game
from brain_games.games import gcd_game


def greet():
    print('Welcome to the Brain Games!')


def main():
    greet()
    return logic_game.play_game(gcd_game.rules,
                                gcd_game.quastion,
                                gcd_game.correct_answer(gcd_game.quastion))


if __name__ == '__main__':
    main()
