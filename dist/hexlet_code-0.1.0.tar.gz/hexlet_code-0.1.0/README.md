### Hexlet tests and linter status:
[![Actions Status](https://github.com/tpl-86/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tpl-86/python-project-49/actions)

https://asciinema.org/a/QloM8rOPwKGKmuY434GT7Kowf
